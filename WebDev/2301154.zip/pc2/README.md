My submission for the DevAThon 2024 contest hosted by The Programming Club of IIIT-Guwahati.
The website is a replica of https://georgerahul24.github.io/DevAThon-2024
